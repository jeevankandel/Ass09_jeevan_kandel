package ass09;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class FetchingData {

	
	static List<Movie> populateMovies(File file) throws Exception
	{
		List<Movie> list=new ArrayList<Movie>();	
		  Scanner sc=new Scanner(file);
		
		  String text[]=null;
		  
		  DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		  while(sc.hasNextLine())
			{
				Movie m=new Movie();
				text=sc.nextLine().split(",");
				m.setMovieId(Integer.valueOf(text[0]));
				m.setMovieName(text[1]);
				m.setMovieType(text[2]);
				m.setLanguage(text[3]);
				
				m.setReleaseDate((Date) df.parse("text[4]"));
				m.setCasting(new ArrayList<>(Arrays.asList(text[5].split(","))));
				m.setRating(Double.valueOf(text[6]));
				m.setTotalBusinessDone(Double.valueOf(text[7]));
				list.add(m);	
			}
		
		return list;
	}
	
	public void getMoviesRealeasedInYear(int year) throws Exception
	{
		File file=new File("C:\\Users\\Lap04\\eclipse-workspace\\ass09\\src\\ass09\\MovieDetals");	
		Scanner sc=new Scanner(file);
		String text[] = null;		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		while(sc.hasNextLine())
		{			
			text=sc.nextLine().split(",");			
			int y=df.parse(text[4]).getYear()+1900;			
			if(year==y)
			{				
				System.out.println(text[0]+" "+text[1]+" "+text[2]);
			}			
		}	
		
		
		
	}

	
	public static void getMoviesByActor(List<Movie> m,String actor)
	{
		Iterator it=m.iterator();
		while(it.hasNext())
		{
			Movie e=(Movie) it.next();
			if(e.getCasting().contains(actor))
			    System.out.println(e.toString());
		}
	}
	public static void addMovie(Movie movie,List<Movie> movies)
	{
		int s=movies.size();
		movies.add(movie);
		if(s<movies.size())
			System.out.println(movie.toString());
		else
			System.out.println("Data has not added");
		
		
	}	
	public static Set<Movie> businessDone(double amount,List<Movie> m)
	{
		Set<Movie> s=new HashSet<>();
		Iterator it=m.iterator();
		while(it.hasNext())
		{
			Movie e=(Movie) it.next();
			if(e.getTotalBusinessDone()>amount)
			    s.add(e);
		}
		return s;
		
	}
	public static void updateRatings(String movieName, double rating ,List<Movie> movies)
	{		
		Iterator it=movies.iterator();
		while(it.hasNext())
		{
			Movie e=(Movie) it.next();
			if(e.getMovieName().equals(movieName))
			{
				e.setRating(rating);
				System.out.println("Rating Updated");
				System.out.println(e.toString());
			}
		}		
	}
	public static void updateBusiness(String movieName, double amount,List<Movie> movies)
	{
		Iterator it=movies.iterator();
		while(it.hasNext())
		{
			Movie e=(Movie) it.next();
			if(e.getMovieName().equals(movieName))
			{
				e.setTotalBusinessDone(amount);
				System.out.println("TotalBusinessCost Updated");
				System.out.println(e.toString());
			}
		}	
	}
	 public static void main(String[] args) throws Exception {
			File file=new File("C:\\Users\\Lap04\\eclipse-workspace\\ass09\\src\\ass09\\MovieDetails");
			List<Movie> list=new ArrayList<Movie>();
			list=populateMovies(file);
			Iterator it=list.iterator();
			while(it.hasNext())
			{
				Movie e=(Movie) it.next();
				System.out.println(e.toString());
			}
			
	
}
}